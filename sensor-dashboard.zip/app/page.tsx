"use client"

import { useState, useEffect, useCallback } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Power, Thermometer, Settings, Lock, FilterX } from "lucide-react"
import { SensorReading } from "@/components/sensor-reading"
import { DetailedView } from "@/components/detailed-view"
import { SensorGraphs } from "@/components/sensor-graphs"
import { ControlPanel } from "@/components/control-panel"
import { ApiConnectionStatus } from "@/components/api-connection-status"
import type { TuyaConfig } from "@/components/api-configuration"
import { ApiConfiguration } from "@/components/api-configuration"
import { fetchSensorData, controlPump, controlHeatPump, type ConnectionStatus } from "@/lib/tuya-api"
import { AdminLogin } from "@/components/admin-login"
import { AdminSettings } from "@/components/admin-settings"
import { isAuthenticated, logout } from "@/lib/auth"
import { FilterMaintenance, type FilterStatus } from "@/components/filter-maintenance"
import { MotorValveControl, type MotorValve } from "@/components/motor-valve-control"
import { FlowMeter, type FlowMeterData } from "@/components/flow-meter"
import { FlowChart } from "@/components/flow-chart"

export default function Dashboard() {
  const [viewMode, setViewMode] = useState<"compact" | "detailed">("compact")
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>("initializing")
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null)
  const [connectionError, setConnectionError] = useState<string | null>(null)
  const [showLoginDialog, setShowLoginDialog] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [showApiConfig, setShowApiConfig] = useState(false)

  // Check authentication on load
  useEffect(() => {
    setIsAdmin(isAuthenticated())
  }, [])

  // Tuya API configuration
  const [tuyaConfig, setTuyaConfig] = useState<TuyaConfig>({
    apiEndpoint: process.env.NEXT_PUBLIC_TUYA_API_ENDPOINT || "https://openapi.tuyacn.com",
    accessId: "",
    accessSecret: "",
    devices: {
      ph: "",
      conductivity: "",
      temperature: "",
      pressure: "",
      salinity1: "",
      salinity2: "",
      pump: "",
      heatPump: "",
    },
  })

  // Sensor data
  const [sensorData, setSensorData] = useState({
    ph: { value: 7.2, trend: "stable" as const, alarm: false },
    conductivity: { value: 542, trend: "rising" as const, alarm: false },
    temperature: { value: 24.5, trend: "falling" as const, alarm: false },
    pressure: { value: 1.02, trend: "stable" as const, alarm: false },
    salinity1: { value: 35.2, trend: "stable" as const, alarm: false },
    salinity2: { value: 34.8, trend: "rising" as const, alarm: false },
    flow1: { value: 2.3, trend: "stable" as const, alarm: false },
    flow2: { value: 0.8, trend: "falling" as const, alarm: false },
  })

  // Control states
  const [pumpState, setPumpState] = useState(false)
  const [heatPumpState, setHeatPumpState] = useState(false)

  // Alarm thresholds
  const [alarmThresholds, setAlarmThresholds] = useState({
    ph: { min: 6.8, max: 7.8 },
    conductivity: { min: 500, max: 600 },
    temperature: { min: 22, max: 26 },
    pressure: { min: 0.9, max: 1.1 },
    salinity1: { min: 34, max: 36 },
    salinity2: { min: 33, max: 36 },
    flow1: { min: 0.5, max: 5.0 },
    flow2: { min: 0.2, max: 3.0 },
  })

  // Timer settings - updated to include both pump and heat pump timers
  const [timerSettings, setTimerSettings] = useState({
    pump: {
      enabled: false,
      schedules: [
        {
          id: "1",
          startTime: "08:00",
          endTime: "10:00",
          days: ["Monday", "Wednesday", "Friday"],
        },
      ],
    },
    heatPump: {
      enabled: false,
      schedules: [
        {
          id: "1",
          startTime: "06:00",
          endTime: "09:00",
          days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        },
      ],
    },
  })

  // Filter maintenance data
  const [filters, setFilters] = useState<FilterStatus[]>([
    {
      id: "filter1",
      name: "Sediment Filter",
      runtime: 120, // hours
      maxRuntime: 500, // hours
      lastReplaced: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days ago
    },
    {
      id: "filter2",
      name: "Carbon Filter",
      runtime: 350, // hours
      maxRuntime: 600, // hours
      lastReplaced: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(), // 60 days ago
    },
    {
      id: "filter3",
      name: "RO Membrane",
      runtime: 800, // hours
      maxRuntime: 1000, // hours
      lastReplaced: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days ago
    },
    {
      id: "filter4",
      name: "Post Carbon Filter",
      runtime: 450, // hours
      maxRuntime: 700, // hours
      lastReplaced: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(), // 45 days ago
    },
    {
      id: "filter5",
      name: "Mineral Filter",
      runtime: 200, // hours
      maxRuntime: 800, // hours
      lastReplaced: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000).toISOString(), // 40 days ago
    },
  ])

  // Motor valve data
  const [motorValves, setMotorValves] = useState<MotorValve[]>([
    {
      id: "valve1",
      name: "Valve 1 - Main Supply",
      state: true,
      timer: {
        enabled: false,
        schedules: [
          {
            id: "1",
            startTime: "07:00",
            endTime: "22:00",
            days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
          },
        ],
      },
    },
    {
      id: "valve2",
      name: "Valve 2 - Cold Water",
      state: true,
      timer: {
        enabled: false,
        schedules: [
          {
            id: "1",
            startTime: "06:00",
            endTime: "23:00",
            days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
          },
        ],
      },
    },
    {
      id: "valve3",
      name: "Valve 3 - Hot Water",
      state: false,
      timer: {
        enabled: false,
        schedules: [
          {
            id: "1",
            startTime: "05:00",
            endTime: "08:00",
            days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          },
          {
            id: "2",
            startTime: "17:00",
            endTime: "22:00",
            days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          },
        ],
      },
    },
    {
      id: "valve4",
      name: "Valve 4 - Bypass",
      state: false,
      timer: {
        enabled: false,
        schedules: [
          {
            id: "1",
            startTime: "00:00",
            endTime: "00:00",
            days: [],
          },
        ],
      },
    },
  ])

  // Flow meter data
  const [flowMeters, setFlowMeters] = useState<FlowMeterData[]>([
    {
      id: "flow1",
      name: "Main Flow Meter",
      currentFlow: 2.3,
      totalFlow: 1250.6,
      maxFlow: 5.0,
      trend: "stable" as const,
      history: Array.from({ length: 24 }, (_, i) => ({
        time: `${i}:00`,
        value: 1.5 + Math.random() * 1.5,
      })),
    },
    {
      id: "flow2",
      name: "Hot Water Flow Meter",
      currentFlow: 0.8,
      totalFlow: 420.3,
      maxFlow: 3.0,
      trend: "falling" as const,
      history: Array.from({ length: 24 }, (_, i) => ({
        time: `${i}:00`,
        value: 0.5 + Math.random() * 1.0,
      })),
    },
  ])

  // Fetch data from Tuya API
  const fetchData = useCallback(async () => {
    setConnectionStatus("initializing")

    try {
      const result = await fetchSensorData(alarmThresholds)
      setSensorData(result.data)
      setConnectionStatus(result.status)
      setLastUpdated(new Date())

      if (result.error) {
        setConnectionError(result.error)
      } else {
        setConnectionError(null)
      }

      // Update pump runtime for filters when pump is running
      if (pumpState) {
        setFilters((prevFilters) =>
          prevFilters.map((filter) => ({
            ...filter,
            runtime: filter.runtime + 1 / 60, // Add 1 minute of runtime
          })),
        )
      }

      // Update flow meter data with real values from API
      setFlowMeters((prevMeters) => {
        return prevMeters.map((meter) => {
          const newFlow = meter.id === "flow1" ? result.data.flow1.value : result.data.flow2.value

          const trend: "rising" | "falling" | "stable" =
            meter.id === "flow1" ? result.data.flow1.trend : result.data.flow2.trend

          // Add to total flow if there is flow
          const addedFlow = newFlow > 0 ? newFlow / 60 : 0 // Convert m³/h to m³/minute

          // Update history
          const now = new Date()
          const timeStr = `${now.getHours()}:${now.getMinutes().toString().padStart(2, "0")}`
          const history = [...meter.history.slice(-23), { time: timeStr, value: newFlow }]

          return {
            ...meter,
            currentFlow: newFlow,
            totalFlow: meter.totalFlow + addedFlow,
            trend,
            history,
          }
        })
      })
    } catch (error) {
      setConnectionStatus("error")
      setConnectionError(error instanceof Error ? error.message : "Failed to fetch data")
      console.error("Error fetching sensor data:", error)
    }
  }, [alarmThresholds, pumpState])

  // Initial data fetch
  useEffect(() => {
    fetchData()
    // Set up polling interval
    const interval = setInterval(fetchData, 60000) // Fetch every minute

    return () => clearInterval(interval)
  }, [fetchData]) // Use the memoized fetchData function

  // Handle pump state change
  const handlePumpStateChange = useCallback(
    async (state: boolean) => {
      if (timerSettings.pump.enabled || pumpState === state) return // Don't update if timer is enabled or state is the same

      try {
        const success = await controlPump(state)
        if (success) {
          setPumpState(state)
        }
      } catch (error) {
        console.error("Error controlling pump:", error)
      }
    },
    [timerSettings.pump.enabled, pumpState],
  )

  // Handle heat pump state change
  const handleHeatPumpStateChange = useCallback(
    async (state: boolean) => {
      if (timerSettings.heatPump.enabled || heatPumpState === state) return // Don't update if timer is enabled or state is the same

      try {
        const success = await controlHeatPump(state)
        if (success) {
          setHeatPumpState(state)
        }
      } catch (error) {
        console.error("Error controlling heat pump:", error)
      }
    },
    [timerSettings.heatPump.enabled, heatPumpState],
  )

  // Handle valve state change
  const handleValveStateChange = useCallback((id: string, state: boolean) => {
    setMotorValves((prevValves) => prevValves.map((valve) => (valve.id === id ? { ...valve, state } : valve)))
  }, [])

  // Handle valve timer change
  const handleValveTimerChange = useCallback((id: string, timer: any) => {
    setMotorValves((prevValves) => prevValves.map((valve) => (valve.id === id ? { ...valve, timer } : valve)))
  }, [])

  // Reset filter runtime
  const handleResetFilter = useCallback((id: string) => {
    setFilters((prevFilters) =>
      prevFilters.map((filter) =>
        filter.id === id
          ? {
              ...filter,
              runtime: 0,
              lastReplaced: new Date().toISOString(),
            }
          : filter,
      ),
    )
  }, [])

  // Update filter max runtime
  const handleUpdateMaxRuntime = useCallback((id: string, maxRuntime: number) => {
    setFilters((prevFilters) => prevFilters.map((filter) => (filter.id === id ? { ...filter, maxRuntime } : filter)))
  }, [])

  // Reset flow meter total
  const handleResetTotalFlow = useCallback((id: string) => {
    setFlowMeters((prevMeters) => prevMeters.map((meter) => (meter.id === id ? { ...meter, totalFlow: 0 } : meter)))
  }, [])

  // Check if any timer is active for pump
  useEffect(() => {
    if (!timerSettings.pump.enabled) {
      return
    }

    const checkPumpTimers = () => {
      const now = new Date()
      const currentDay = now.toLocaleDateString("en-US", { weekday: "long" })
      const currentTime = now.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" })

      const isTimeInRange = timerSettings.pump.schedules.some((schedule) => {
        if (!schedule.days.includes(currentDay)) {
          return false
        }

        return currentTime >= schedule.startTime && currentTime <= schedule.endTime
      })

      // Only update if the state would actually change
      if (pumpState !== isTimeInRange) {
        handlePumpStateChange(isTimeInRange)
      }
    }

    const interval = setInterval(checkPumpTimers, 1000)
    checkPumpTimers() // Check immediately

    return () => clearInterval(interval)
  }, [timerSettings.pump.enabled, timerSettings.pump.schedules, pumpState, handlePumpStateChange])

  // Check if any timer is active for heat pump
  useEffect(() => {
    if (!timerSettings.heatPump.enabled) {
      return
    }

    const checkHeatPumpTimers = () => {
      const now = new Date()
      const currentDay = now.toLocaleDateString("en-US", { weekday: "long" })
      const currentTime = now.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" })

      const isTimeInRange = timerSettings.heatPump.schedules.some((schedule) => {
        if (!schedule.days.includes(currentDay)) {
          return false
        }

        return currentTime >= schedule.startTime && currentTime <= schedule.endTime
      })

      // Only update if the state would actually change
      if (heatPumpState !== isTimeInRange) {
        handleHeatPumpStateChange(isTimeInRange)
      }
    }

    const interval = setInterval(checkHeatPumpTimers, 1000)
    checkHeatPumpTimers() // Check immediately

    return () => clearInterval(interval)
  }, [timerSettings.heatPump.enabled, timerSettings.heatPump.schedules, heatPumpState, handleHeatPumpStateChange])

  // Check valve timers
  useEffect(() => {
    const checkValveTimers = () => {
      const now = new Date()
      const currentDay = now.toLocaleDateString("en-US", { weekday: "long" })
      const currentTime = now.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit" })

      setMotorValves((prevValves) => {
        // Check if any valve state would change
        const needsUpdate = prevValves.some((valve) => {
          if (!valve.timer.enabled) return false

          const isTimeInRange = valve.timer.schedules.some((schedule) => {
            if (!schedule.days.includes(currentDay)) {
              return false
            }
            return currentTime >= schedule.startTime && currentTime <= schedule.endTime
          })

          // Only update if the state would actually change
          return valve.state !== isTimeInRange
        })

        // If no changes needed, return the same array reference to prevent re-render
        if (!needsUpdate) return prevValves

        // Otherwise, update the valves that need changing
        return prevValves.map((valve) => {
          if (!valve.timer.enabled) return valve

          const isTimeInRange = valve.timer.schedules.some((schedule) => {
            if (!schedule.days.includes(currentDay)) {
              return false
            }
            return currentTime >= schedule.startTime && currentTime <= schedule.endTime
          })

          return valve.state !== isTimeInRange ? { ...valve, state: isTimeInRange } : valve
        })
      })
    }

    const interval = setInterval(checkValveTimers, 1000)
    checkValveTimers() // Check immediately

    return () => clearInterval(interval)
  }, [])

  // Save Tuya configuration
  const handleSaveTuyaConfig = useCallback(
    (config: TuyaConfig) => {
      setTuyaConfig(config)
      // In a real implementation, we would store this in localStorage or a database
      // and update environment variables

      // Refresh data with new configuration
      fetchData()
    },
    [fetchData],
  )

  // Handle admin login
  const handleAdminLogin = useCallback(() => {
    setIsAdmin(true)
    setShowLoginDialog(false)
  }, [])

  // Handle admin logout
  const handleAdminLogout = useCallback(() => {
    logout()
    setIsAdmin(false)
  }, [])

  // Show login dialog when clicking admin button
  const handleAdminButtonClick = useCallback(() => {
    if (isAdmin) {
      // Already logged in, do nothing
    } else {
      setShowLoginDialog(true)
    }
  }, [isAdmin])

  return (
    <div className="container mx-auto p-4">
      <header className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <div className="mr-4 rotate-90">
            <img src="/logo.png" alt="SWATEC Logo" className="h-12" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">SWATEC</h1>
            <p className="text-sm text-muted-foreground">Sensor Monitoring Dashboard</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <ApiConnectionStatus status={connectionStatus} onRefresh={fetchData} lastUpdated={lastUpdated} />
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setViewMode(viewMode === "compact" ? "detailed" : "compact")}
            >
              {viewMode === "compact" ? "Detailed View" : "Compact View"}
            </Button>
            <Button variant={isAdmin ? "default" : "outline"} size="sm" onClick={handleAdminButtonClick}>
              <Lock className="h-4 w-4 mr-2" />
              {isAdmin ? "Admin Panel" : "Admin Login"}
            </Button>
          </div>
        </div>
      </header>

      <Tabs defaultValue="dashboard">
        <TabsList className="mb-4">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="graphs">Graphs</TabsTrigger>
          <TabsTrigger value="flow-charts">Flow Charts</TabsTrigger>
          <TabsTrigger value="controls">Controls</TabsTrigger>
          <TabsTrigger value="flow">Flow Meters</TabsTrigger>
          <TabsTrigger value="valves">Motor Valves</TabsTrigger>
          <TabsTrigger value="filters">Filter Maintenance</TabsTrigger>
          {isAdmin && <TabsTrigger value="admin">Admin Settings</TabsTrigger>}
        </TabsList>

        <TabsContent value="dashboard">
          {connectionError && connectionStatus !== "disconnected" && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md text-red-600 text-sm">
              <strong>Connection Error:</strong> {connectionError}
            </div>
          )}

          {connectionStatus === "disconnected" && (
            <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md text-yellow-700 text-sm flex justify-between items-center">
              <div>
                <strong>API Not Connected:</strong>{" "}
                {connectionError || "Please configure your Tuya API credentials in API Settings."}
              </div>
              {isAdmin ? (
                <Button size="sm" variant="outline" onClick={() => setShowApiConfig(true)}>
                  <Settings className="h-4 w-4 mr-2" />
                  Configure API
                </Button>
              ) : (
                <Button size="sm" variant="outline" onClick={handleAdminButtonClick}>
                  <Lock className="h-4 w-4 mr-2" />
                  Admin Login
                </Button>
              )}
            </div>
          )}

          {viewMode === "compact" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <SensorReading
                title="pH"
                value={sensorData.ph.value}
                unit=""
                trend={sensorData.ph.trend}
                alarm={sensorData.ph.alarm}
                min={alarmThresholds.ph.min}
                max={alarmThresholds.ph.max}
              />
              <SensorReading
                title="Conductivity"
                value={sensorData.conductivity.value}
                unit="μS/cm"
                trend={sensorData.conductivity.trend}
                alarm={sensorData.conductivity.alarm}
                min={alarmThresholds.conductivity.min}
                max={alarmThresholds.conductivity.max}
              />
              <SensorReading
                title="Temperature"
                value={sensorData.temperature.value}
                unit="°C"
                trend={sensorData.temperature.trend}
                alarm={sensorData.temperature.alarm}
                min={alarmThresholds.temperature.min}
                max={alarmThresholds.temperature.max}
              />
              <SensorReading
                title="Pressure"
                value={sensorData.pressure.value}
                unit="bar"
                trend={sensorData.pressure.trend}
                alarm={sensorData.pressure.alarm}
                min={alarmThresholds.pressure.min}
                max={alarmThresholds.pressure.max}
              />
              <SensorReading
                title="Salinity 1"
                value={sensorData.salinity1.value}
                unit="ppt"
                trend={sensorData.salinity1.trend}
                alarm={sensorData.salinity1.alarm}
                min={alarmThresholds.salinity1.min}
                max={alarmThresholds.salinity1.max}
              />
              <SensorReading
                title="Salinity 2"
                value={sensorData.salinity2.value}
                unit="ppt"
                trend={sensorData.salinity2.trend}
                alarm={sensorData.salinity2.alarm}
                min={alarmThresholds.salinity2.min}
                max={alarmThresholds.salinity2.max}
              />

              {/* Add Flow Meter readings to dashboard */}
              <SensorReading
                title="Main Flow"
                value={sensorData.flow1.value}
                unit="m³/h"
                trend={sensorData.flow1.trend}
                alarm={sensorData.flow1.alarm}
                min={alarmThresholds.flow1.min}
                max={alarmThresholds.flow1.max}
              />
              <SensorReading
                title="Hot Water Flow"
                value={sensorData.flow2.value}
                unit="m³/h"
                trend={sensorData.flow2.trend}
                alarm={sensorData.flow2.alarm}
                min={alarmThresholds.flow2.min}
                max={alarmThresholds.flow2.max}
              />

              <Card className="col-span-1 md:col-span-2 lg:col-span-3">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Control Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-4">
                    <div className="flex items-center">
                      <Badge variant={pumpState ? "default" : "outline"} className="mr-2">
                        <Power className="h-3 w-3 mr-1" />
                        Pump
                      </Badge>
                      <span className={pumpState ? "text-green-500" : "text-gray-500"}>
                        {pumpState ? "Running" : "Off"}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Badge variant={heatPumpState ? "default" : "outline"} className="mr-2">
                        <Thermometer className="h-3 w-3 mr-1" />
                        Heat Pump
                      </Badge>
                      <span className={heatPumpState ? "text-green-500" : "text-gray-500"}>
                        {heatPumpState ? "Running" : "Off"}
                      </span>
                    </div>
                    <div className="flex items-center ml-auto">
                      <Badge variant={timerSettings.pump.enabled ? "default" : "outline"} className="mr-2">
                        <Clock className="h-3 w-3 mr-1" />
                        Pump Timer
                      </Badge>
                      <span className={timerSettings.pump.enabled ? "text-green-500" : "text-gray-500"}>
                        {timerSettings.pump.enabled ? "Enabled" : "Disabled"}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Badge variant={timerSettings.heatPump.enabled ? "default" : "outline"} className="mr-2">
                        <Clock className="h-3 w-3 mr-1" />
                        Heat Pump Timer
                      </Badge>
                      <span className={timerSettings.heatPump.enabled ? "text-green-500" : "text-gray-500"}>
                        {timerSettings.heatPump.enabled ? "Enabled" : "Disabled"}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <DetailedView
              sensorData={sensorData}
              alarmThresholds={alarmThresholds}
              pumpState={pumpState}
              heatPumpState={heatPumpState}
              timerSettings={timerSettings}
            />
          )}
        </TabsContent>

        <TabsContent value="graphs">
          <SensorGraphs sensorData={sensorData} alarmThresholds={alarmThresholds} />
        </TabsContent>

        <TabsContent value="flow-charts">
          <FlowChart
            flowData={{
              flow1: sensorData.flow1,
              flow2: sensorData.flow2,
            }}
            flowThresholds={{
              flow1: alarmThresholds.flow1,
              flow2: alarmThresholds.flow2,
            }}
          />
        </TabsContent>

        <TabsContent value="controls">
          <ControlPanel
            pumpState={pumpState}
            heatPumpState={heatPumpState}
            setPumpState={handlePumpStateChange}
            setHeatPumpState={handleHeatPumpStateChange}
            timerSettings={timerSettings}
            setTimerSettings={setTimerSettings}
          />
        </TabsContent>

        <TabsContent value="flow">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {flowMeters.map((flowMeter) => (
              <FlowMeter key={flowMeter.id} flowMeter={flowMeter} onResetTotalFlow={handleResetTotalFlow} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="valves">
          <MotorValveControl
            valves={motorValves}
            onValveStateChange={handleValveStateChange}
            onValveTimerChange={handleValveTimerChange}
          />
        </TabsContent>

        <TabsContent value="filters">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FilterX className="h-5 w-5 mr-2" />
                  Filter Maintenance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <FilterMaintenance
                  filters={filters}
                  onResetFilter={handleResetFilter}
                  onUpdateMaxRuntime={handleUpdateMaxRuntime}
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {isAdmin && (
          <TabsContent value="admin">
            <AdminSettings
              alarmThresholds={alarmThresholds}
              setAlarmThresholds={setAlarmThresholds}
              timerSettings={timerSettings}
              setTimerSettings={setTimerSettings}
              tuyaConfig={tuyaConfig}
              onSaveTuyaConfig={handleSaveTuyaConfig}
              onLogout={handleAdminLogout}
            />
          </TabsContent>
        )}
      </Tabs>

      {showLoginDialog && (
        <AdminLogin open={showLoginDialog} onClose={() => setShowLoginDialog(false)} onLogin={handleAdminLogin} />
      )}

      {showApiConfig && (
        <ApiConfiguration
          open={showApiConfig}
          onClose={() => setShowApiConfig(false)}
          onSave={handleSaveTuyaConfig}
          config={tuyaConfig}
        />
      )}
    </div>
  )
}
