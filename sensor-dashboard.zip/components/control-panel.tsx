"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Clock, Power, Thermometer } from "lucide-react"

type Schedule = {
  id: string
  startTime: string
  endTime: string
  days: string[]
}

type DeviceTimerSettings = {
  enabled: boolean
  schedules: Schedule[]
}

type TimerSettings = {
  pump: DeviceTimerSettings
  heatPump: DeviceTimerSettings
}

interface ControlPanelProps {
  pumpState: boolean
  heatPumpState: boolean
  setPumpState: (state: boolean) => void
  setHeatPumpState: (state: boolean) => void
  timerSettings: TimerSettings
  setTimerSettings: (settings: TimerSettings) => void
}

export function ControlPanel({
  pumpState,
  heatPumpState,
  setPumpState,
  setHeatPumpState,
  timerSettings,
  setTimerSettings,
}: ControlPanelProps) {
  const toggleTimer = (device: "pump" | "heatPump") => {
    setTimerSettings({
      ...timerSettings,
      [device]: {
        ...timerSettings[device],
        enabled: !timerSettings[device].enabled,
      },
    })
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Pump Control</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Power className="h-5 w-5" />
                  <Label htmlFor="pump-switch">Pump Power</Label>
                </div>
                <Switch
                  id="pump-switch"
                  checked={pumpState}
                  onCheckedChange={setPumpState}
                  disabled={timerSettings.pump.enabled}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5" />
                  <Label htmlFor="pump-timer-switch">Timer Control</Label>
                </div>
                <Switch
                  id="pump-timer-switch"
                  checked={timerSettings.pump.enabled}
                  onCheckedChange={() => toggleTimer("pump")}
                />
              </div>
            </div>

            <div className="pt-2 border-t">
              <h3 className="text-sm font-medium mb-2">Status</h3>
              <div className="flex items-center space-x-2">
                <Badge variant={pumpState ? "default" : "outline"}>
                  <Power className="h-3 w-3 mr-1" />
                  {pumpState ? "Running" : "Off"}
                </Badge>

                {timerSettings.pump.enabled && (
                  <Badge variant="secondary">
                    <Clock className="h-3 w-3 mr-1" />
                    Timer Active
                  </Badge>
                )}
              </div>
            </div>

            {timerSettings.pump.enabled && timerSettings.pump.schedules.length > 0 && (
              <div className="pt-2 border-t">
                <h3 className="text-sm font-medium mb-2">Active Schedules</h3>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {timerSettings.pump.schedules.map((schedule) => (
                    <div key={schedule.id} className="text-sm p-2 bg-muted rounded-md">
                      <div className="font-medium">
                        {schedule.startTime} - {schedule.endTime}
                      </div>
                      <div className="text-xs text-muted-foreground">{schedule.days.join(", ")}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end space-x-2 pt-2">
              <Button variant="outline" onClick={() => setPumpState(false)} disabled={timerSettings.pump.enabled}>
                Turn Off
              </Button>
              <Button onClick={() => setPumpState(true)} disabled={timerSettings.pump.enabled}>
                Turn On
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Heat Pump Control</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Thermometer className="h-5 w-5" />
                  <Label htmlFor="heat-pump-switch">Heat Pump Power</Label>
                </div>
                <Switch
                  id="heat-pump-switch"
                  checked={heatPumpState}
                  onCheckedChange={setHeatPumpState}
                  disabled={timerSettings.heatPump.enabled}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5" />
                  <Label htmlFor="heat-pump-timer-switch">Timer Control</Label>
                </div>
                <Switch
                  id="heat-pump-timer-switch"
                  checked={timerSettings.heatPump.enabled}
                  onCheckedChange={() => toggleTimer("heatPump")}
                />
              </div>
            </div>

            <div className="pt-2 border-t">
              <h3 className="text-sm font-medium mb-2">Status</h3>
              <div className="flex items-center space-x-2">
                <Badge variant={heatPumpState ? "default" : "outline"}>
                  <Thermometer className="h-3 w-3 mr-1" />
                  {heatPumpState ? "Running" : "Off"}
                </Badge>

                {timerSettings.heatPump.enabled && (
                  <Badge variant="secondary">
                    <Clock className="h-3 w-3 mr-1" />
                    Timer Active
                  </Badge>
                )}
              </div>
            </div>

            {timerSettings.heatPump.enabled && timerSettings.heatPump.schedules.length > 0 && (
              <div className="pt-2 border-t">
                <h3 className="text-sm font-medium mb-2">Active Schedules</h3>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {timerSettings.heatPump.schedules.map((schedule) => (
                    <div key={schedule.id} className="text-sm p-2 bg-muted rounded-md">
                      <div className="font-medium">
                        {schedule.startTime} - {schedule.endTime}
                      </div>
                      <div className="text-xs text-muted-foreground">{schedule.days.join(", ")}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end space-x-2 pt-2">
              <Button
                variant="outline"
                onClick={() => setHeatPumpState(false)}
                disabled={timerSettings.heatPump.enabled}
              >
                Turn Off
              </Button>
              <Button onClick={() => setHeatPumpState(true)} disabled={timerSettings.heatPump.enabled}>
                Turn On
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
