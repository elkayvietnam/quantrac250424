import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowDown, ArrowUp, Minus, Bell, Clock, Power, Thermometer } from "lucide-react"
import { Progress } from "@/components/ui/progress"

type SensorData = {
  ph: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  conductivity: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  temperature: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  pressure: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  salinity1: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  salinity2: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
}

type AlarmThresholds = {
  ph: { min: number; max: number }
  conductivity: { min: number; max: number }
  temperature: { min: number; max: number }
  pressure: { min: number; max: number }
  salinity1: { min: number; max: number }
  salinity2: { min: number; max: number }
}

type Schedule = {
  id: string
  startTime: string
  endTime: string
  days: string[]
}

type DeviceTimerSettings = {
  enabled: boolean
  schedules: Schedule[]
}

type TimerSettings = {
  pump: DeviceTimerSettings
  heatPump: DeviceTimerSettings
}

interface DetailedViewProps {
  sensorData: SensorData
  alarmThresholds: AlarmThresholds
  pumpState: boolean
  heatPumpState: boolean
  timerSettings: TimerSettings
}

export function DetailedView({
  sensorData,
  alarmThresholds,
  pumpState,
  heatPumpState,
  timerSettings,
}: DetailedViewProps) {
  const getTrendIcon = (trend: "rising" | "falling" | "stable") => {
    switch (trend) {
      case "rising":
        return <ArrowUp className="h-4 w-4 text-green-500" />
      case "falling":
        return <ArrowDown className="h-4 w-4 text-red-500" />
      case "stable":
        return <Minus className="h-4 w-4 text-gray-500" />
    }
  }

  const getProgressValue = (value: number, min: number, max: number) => {
    return ((value - min) / (max - min)) * 100
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>pH</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <div className="text-3xl font-bold">{sensorData.ph.value}</div>
            <div className="flex items-center">
              {getTrendIcon(sensorData.ph.trend)}
              <span className="ml-1">{sensorData.ph.trend}</span>
              {sensorData.ph.alarm && (
                <Badge variant="destructive" className="ml-2">
                  <Bell className="h-3 w-3 mr-1" />
                  Alarm
                </Badge>
              )}
            </div>
          </div>
          <div className="mb-4">
            <Progress
              value={getProgressValue(sensorData.ph.value, alarmThresholds.ph.min - 1, alarmThresholds.ph.max + 1)}
            />
            <div className="flex justify-between text-xs mt-1">
              <span>{alarmThresholds.ph.min - 1}</span>
              <span>{alarmThresholds.ph.max + 1}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Min Threshold:</span> {alarmThresholds.ph.min}
            </div>
            <div>
              <span className="font-medium">Max Threshold:</span> {alarmThresholds.ph.max}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Conductivity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <div className="text-3xl font-bold">
              {sensorData.conductivity.value} <span className="text-sm">μS/cm</span>
            </div>
            <div className="flex items-center">
              {getTrendIcon(sensorData.conductivity.trend)}
              <span className="ml-1">{sensorData.conductivity.trend}</span>
              {sensorData.conductivity.alarm && (
                <Badge variant="destructive" className="ml-2">
                  <Bell className="h-3 w-3 mr-1" />
                  Alarm
                </Badge>
              )}
            </div>
          </div>
          <div className="mb-4">
            <Progress
              value={getProgressValue(
                sensorData.conductivity.value,
                alarmThresholds.conductivity.min - 50,
                alarmThresholds.conductivity.max + 50,
              )}
            />
            <div className="flex justify-between text-xs mt-1">
              <span>{alarmThresholds.conductivity.min - 50}</span>
              <span>{alarmThresholds.conductivity.max + 50}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Min Threshold:</span> {alarmThresholds.conductivity.min} μS/cm
            </div>
            <div>
              <span className="font-medium">Max Threshold:</span> {alarmThresholds.conductivity.max} μS/cm
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Temperature</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <div className="text-3xl font-bold">
              {sensorData.temperature.value} <span className="text-sm">°C</span>
            </div>
            <div className="flex items-center">
              {getTrendIcon(sensorData.temperature.trend)}
              <span className="ml-1">{sensorData.temperature.trend}</span>
              {sensorData.temperature.alarm && (
                <Badge variant="destructive" className="ml-2">
                  <Bell className="h-3 w-3 mr-1" />
                  Alarm
                </Badge>
              )}
            </div>
          </div>
          <div className="mb-4">
            <Progress
              value={getProgressValue(
                sensorData.temperature.value,
                alarmThresholds.temperature.min - 2,
                alarmThresholds.temperature.max + 2,
              )}
            />
            <div className="flex justify-between text-xs mt-1">
              <span>{alarmThresholds.temperature.min - 2}</span>
              <span>{alarmThresholds.temperature.max + 2}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Min Threshold:</span> {alarmThresholds.temperature.min} °C
            </div>
            <div>
              <span className="font-medium">Max Threshold:</span> {alarmThresholds.temperature.max} °C
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Pressure</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <div className="text-3xl font-bold">
              {sensorData.pressure.value} <span className="text-sm">bar</span>
            </div>
            <div className="flex items-center">
              {getTrendIcon(sensorData.pressure.trend)}
              <span className="ml-1">{sensorData.pressure.trend}</span>
              {sensorData.pressure.alarm && (
                <Badge variant="destructive" className="ml-2">
                  <Bell className="h-3 w-3 mr-1" />
                  Alarm
                </Badge>
              )}
            </div>
          </div>
          <div className="mb-4">
            <Progress
              value={getProgressValue(
                sensorData.pressure.value,
                alarmThresholds.pressure.min - 0.1,
                alarmThresholds.pressure.max + 0.1,
              )}
            />
            <div className="flex justify-between text-xs mt-1">
              <span>{alarmThresholds.pressure.min - 0.1}</span>
              <span>{alarmThresholds.pressure.max + 0.1}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Min Threshold:</span> {alarmThresholds.pressure.min} bar
            </div>
            <div>
              <span className="font-medium">Max Threshold:</span> {alarmThresholds.pressure.max} bar
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Salinity 1</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <div className="text-3xl font-bold">
              {sensorData.salinity1.value} <span className="text-sm">ppt</span>
            </div>
            <div className="flex items-center">
              {getTrendIcon(sensorData.salinity1.trend)}
              <span className="ml-1">{sensorData.salinity1.trend}</span>
              {sensorData.salinity1.alarm && (
                <Badge variant="destructive" className="ml-2">
                  <Bell className="h-3 w-3 mr-1" />
                  Alarm
                </Badge>
              )}
            </div>
          </div>
          <div className="mb-4">
            <Progress
              value={getProgressValue(
                sensorData.salinity1.value,
                alarmThresholds.salinity1.min - 1,
                alarmThresholds.salinity1.max + 1,
              )}
            />
            <div className="flex justify-between text-xs mt-1">
              <span>{alarmThresholds.salinity1.min - 1}</span>
              <span>{alarmThresholds.salinity1.max + 1}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Min Threshold:</span> {alarmThresholds.salinity1.min} ppt
            </div>
            <div>
              <span className="font-medium">Max Threshold:</span> {alarmThresholds.salinity1.max} ppt
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Salinity 2</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-2">
            <div className="text-3xl font-bold">
              {sensorData.salinity2.value} <span className="text-sm">ppt</span>
            </div>
            <div className="flex items-center">
              {getTrendIcon(sensorData.salinity2.trend)}
              <span className="ml-1">{sensorData.salinity2.trend}</span>
              {sensorData.salinity2.alarm && (
                <Badge variant="destructive" className="ml-2">
                  <Bell className="h-3 w-3 mr-1" />
                  Alarm
                </Badge>
              )}
            </div>
          </div>
          <div className="mb-4">
            <Progress
              value={getProgressValue(
                sensorData.salinity2.value,
                alarmThresholds.salinity2.min - 1,
                alarmThresholds.salinity2.max + 1,
              )}
            />
            <div className="flex justify-between text-xs mt-1">
              <span>{alarmThresholds.salinity2.min - 1}</span>
              <span>{alarmThresholds.salinity2.max + 1}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Min Threshold:</span> {alarmThresholds.salinity2.min} ppt
            </div>
            <div>
              <span className="font-medium">Max Threshold:</span> {alarmThresholds.salinity2.max} ppt
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Control Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex flex-col">
              <div className="text-lg font-medium mb-2">Pump</div>
              <div className="flex items-center">
                <Badge variant={pumpState ? "default" : "outline"} className="mr-2">
                  <Power className="h-3 w-3 mr-1" />
                  Status
                </Badge>
                <span className={pumpState ? "text-green-500" : "text-gray-500"}>{pumpState ? "Running" : "Off"}</span>
              </div>
              {timerSettings.pump.enabled && (
                <div className="mt-2 text-sm">
                  <div className="flex items-center">
                    <Badge variant="secondary" className="mr-2">
                      <Clock className="h-3 w-3 mr-1" />
                      Timer
                    </Badge>
                    <span className="text-green-500">Enabled</span>
                  </div>
                  <div className="mt-1 text-xs">
                    <div className="font-medium mb-1">Active Schedules:</div>
                    <div className="space-y-1">
                      {timerSettings.pump.schedules.map((schedule) => (
                        <div key={schedule.id} className="text-xs">
                          {schedule.startTime} - {schedule.endTime} ({schedule.days.join(", ")})
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col">
              <div className="text-lg font-medium mb-2">Heat Pump</div>
              <div className="flex items-center">
                <Badge variant={heatPumpState ? "default" : "outline"} className="mr-2">
                  <Thermometer className="h-3 w-3 mr-1" />
                  Status
                </Badge>
                <span className={heatPumpState ? "text-green-500" : "text-gray-500"}>
                  {heatPumpState ? "Running" : "Off"}
                </span>
              </div>
              {timerSettings.heatPump.enabled && (
                <div className="mt-2 text-sm">
                  <div className="flex items-center">
                    <Badge variant="secondary" className="mr-2">
                      <Clock className="h-3 w-3 mr-1" />
                      Timer
                    </Badge>
                    <span className="text-green-500">Enabled</span>
                  </div>
                  <div className="mt-1 text-xs">
                    <div className="font-medium mb-1">Active Schedules:</div>
                    <div className="space-y-1">
                      {timerSettings.heatPump.schedules.map((schedule) => (
                        <div key={schedule.id} className="text-xs">
                          {schedule.startTime} - {schedule.endTime} ({schedule.days.join(", ")})
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col">
              <div className="text-lg font-medium mb-2">Timer Status</div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Badge variant={timerSettings.pump.enabled ? "default" : "outline"} className="mr-2">
                    <Clock className="h-3 w-3 mr-1" />
                    Pump Timer
                  </Badge>
                  <span className={timerSettings.pump.enabled ? "text-green-500" : "text-gray-500"}>
                    {timerSettings.pump.enabled ? "Enabled" : "Disabled"}
                  </span>
                </div>
                <div className="flex items-center">
                  <Badge variant={timerSettings.heatPump.enabled ? "default" : "outline"} className="mr-2">
                    <Clock className="h-3 w-3 mr-1" />
                    Heat Pump Timer
                  </Badge>
                  <span className={timerSettings.heatPump.enabled ? "text-green-500" : "text-gray-500"}>
                    {timerSettings.heatPump.enabled ? "Enabled" : "Disabled"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
