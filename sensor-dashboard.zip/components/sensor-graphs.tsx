"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts"

type SensorData = {
  ph: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  conductivity: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  temperature: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  pressure: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  salinity1: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  salinity2: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
}

type AlarmThresholds = {
  ph: { min: number; max: number }
  conductivity: { min: number; max: number }
  temperature: { min: number; max: number }
  pressure: { min: number; max: number }
  salinity1: { min: number; max: number }
  salinity2: { min: number; max: number }
}

interface SensorGraphsProps {
  sensorData: SensorData
  alarmThresholds: AlarmThresholds
}

// Generate mock historical data
const generateHistoricalData = (currentValue: number, min: number, max: number, dataPoints = 24) => {
  const data = []
  let value = currentValue

  const now = new Date()

  for (let i = dataPoints - 1; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 3600000) // hourly data
    const timeStr = time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })

    // Random walk with boundaries
    const change = (Math.random() - 0.5) * (max - min) * 0.05
    value = Math.max(min * 0.9, Math.min(max * 1.1, value + change))

    data.push({
      time: timeStr,
      value: Number.parseFloat(value.toFixed(2)),
    })
  }

  return data
}

export function SensorGraphs({ sensorData, alarmThresholds }: SensorGraphsProps) {
  // Generate historical data for each sensor
  const [phData] = useState(generateHistoricalData(sensorData.ph.value, alarmThresholds.ph.min, alarmThresholds.ph.max))

  const [conductivityData] = useState(
    generateHistoricalData(
      sensorData.conductivity.value,
      alarmThresholds.conductivity.min,
      alarmThresholds.conductivity.max,
    ),
  )

  const [temperatureData] = useState(
    generateHistoricalData(
      sensorData.temperature.value,
      alarmThresholds.temperature.min,
      alarmThresholds.temperature.max,
    ),
  )

  const [pressureData] = useState(
    generateHistoricalData(sensorData.pressure.value, alarmThresholds.pressure.min, alarmThresholds.pressure.max),
  )

  const [salinity1Data] = useState(
    generateHistoricalData(sensorData.salinity1.value, alarmThresholds.salinity1.min, alarmThresholds.salinity1.max),
  )

  const [salinity2Data] = useState(
    generateHistoricalData(sensorData.salinity2.value, alarmThresholds.salinity2.min, alarmThresholds.salinity2.max),
  )

  return (
    <div className="space-y-6">
      <Tabs defaultValue="ph">
        <TabsList className="grid grid-cols-3 md:grid-cols-6">
          <TabsTrigger value="ph">pH</TabsTrigger>
          <TabsTrigger value="conductivity">Conductivity</TabsTrigger>
          <TabsTrigger value="temperature">Temperature</TabsTrigger>
          <TabsTrigger value="pressure">Pressure</TabsTrigger>
          <TabsTrigger value="salinity1">Salinity 1</TabsTrigger>
          <TabsTrigger value="salinity2">Salinity 2</TabsTrigger>
        </TabsList>

        <TabsContent value="ph">
          <Card>
            <CardHeader>
              <CardTitle>pH History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={phData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis
                      domain={[
                        Math.min(alarmThresholds.ph.min * 0.9, Math.min(...phData.map((d) => d.value))),
                        Math.max(alarmThresholds.ph.max * 1.1, Math.max(...phData.map((d) => d.value))),
                      ]}
                    />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine y={alarmThresholds.ph.min} stroke="red" strokeDasharray="3 3" />
                    <ReferenceLine y={alarmThresholds.ph.max} stroke="red" strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="value" stroke="#8884d8" activeDot={{ r: 8 }} name="pH" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="conductivity">
          <Card>
            <CardHeader>
              <CardTitle>Conductivity History (μS/cm)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={conductivityData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis
                      domain={[
                        Math.min(
                          alarmThresholds.conductivity.min * 0.9,
                          Math.min(...conductivityData.map((d) => d.value)),
                        ),
                        Math.max(
                          alarmThresholds.conductivity.max * 1.1,
                          Math.max(...conductivityData.map((d) => d.value)),
                        ),
                      ]}
                    />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine y={alarmThresholds.conductivity.min} stroke="red" strokeDasharray="3 3" />
                    <ReferenceLine y={alarmThresholds.conductivity.max} stroke="red" strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="value" stroke="#82ca9d" activeDot={{ r: 8 }} name="Conductivity" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="temperature">
          <Card>
            <CardHeader>
              <CardTitle>Temperature History (°C)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={temperatureData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis
                      domain={[
                        Math.min(
                          alarmThresholds.temperature.min * 0.9,
                          Math.min(...temperatureData.map((d) => d.value)),
                        ),
                        Math.max(
                          alarmThresholds.temperature.max * 1.1,
                          Math.max(...temperatureData.map((d) => d.value)),
                        ),
                      ]}
                    />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine y={alarmThresholds.temperature.min} stroke="red" strokeDasharray="3 3" />
                    <ReferenceLine y={alarmThresholds.temperature.max} stroke="red" strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="value" stroke="#ff7300" activeDot={{ r: 8 }} name="Temperature" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pressure">
          <Card>
            <CardHeader>
              <CardTitle>Pressure History (bar)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={pressureData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis
                      domain={[
                        Math.min(alarmThresholds.pressure.min * 0.9, Math.min(...pressureData.map((d) => d.value))),
                        Math.max(alarmThresholds.pressure.max * 1.1, Math.max(...pressureData.map((d) => d.value))),
                      ]}
                    />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine y={alarmThresholds.pressure.min} stroke="red" strokeDasharray="3 3" />
                    <ReferenceLine y={alarmThresholds.pressure.max} stroke="red" strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="value" stroke="#0088fe" activeDot={{ r: 8 }} name="Pressure" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="salinity1">
          <Card>
            <CardHeader>
              <CardTitle>Salinity 1 History (ppt)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={salinity1Data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis
                      domain={[
                        Math.min(alarmThresholds.salinity1.min * 0.9, Math.min(...salinity1Data.map((d) => d.value))),
                        Math.max(alarmThresholds.salinity1.max * 1.1, Math.max(...salinity1Data.map((d) => d.value))),
                      ]}
                    />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine y={alarmThresholds.salinity1.min} stroke="red" strokeDasharray="3 3" />
                    <ReferenceLine y={alarmThresholds.salinity1.max} stroke="red" strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="value" stroke="#8884d8" activeDot={{ r: 8 }} name="Salinity 1" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="salinity2">
          <Card>
            <CardHeader>
              <CardTitle>Salinity 2 History (ppt)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={salinity2Data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis
                      domain={[
                        Math.min(alarmThresholds.salinity2.min * 0.9, Math.min(...salinity2Data.map((d) => d.value))),
                        Math.max(alarmThresholds.salinity2.max * 1.1, Math.max(...salinity2Data.map((d) => d.value))),
                      ]}
                    />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine y={alarmThresholds.salinity2.min} stroke="red" strokeDasharray="3 3" />
                    <ReferenceLine y={alarmThresholds.salinity2.max} stroke="red" strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="value" stroke="#82ca9d" activeDot={{ r: 8 }} name="Salinity 2" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
