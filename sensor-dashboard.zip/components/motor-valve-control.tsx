"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Clock, Power } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"

type Schedule = {
  id: string
  startTime: string
  endTime: string
  days: string[]
}

type ValveTimerSettings = {
  enabled: boolean
  schedules: Schedule[]
}

export type MotorValve = {
  id: string
  name: string
  state: boolean
  timer: ValveTimerSettings
}

interface MotorValveControlProps {
  valves: MotorValve[]
  onValveStateChange: (id: string, state: boolean) => void
  onValveTimerChange: (id: string, timer: ValveTimerSettings) => void
}

export function MotorValveControl({ valves, onValveStateChange, onValveTimerChange }: MotorValveControlProps) {
  const [selectedValve, setSelectedValve] = useState<MotorValve | null>(null)
  const [showTimerSettings, setShowTimerSettings] = useState(false)
  const [localTimerSettings, setLocalTimerSettings] = useState<ValveTimerSettings | null>(null)

  const handleOpenTimerSettings = (valve: MotorValve) => {
    setSelectedValve(valve)
    setLocalTimerSettings({
      enabled: valve.timer.enabled,
      schedules: [...valve.timer.schedules],
    })
    setShowTimerSettings(true)
  }

  const handleSaveTimerSettings = () => {
    if (selectedValve && localTimerSettings) {
      onValveTimerChange(selectedValve.id, localTimerSettings)
    }
    setShowTimerSettings(false)
  }

  const toggleTimer = (enabled: boolean) => {
    if (localTimerSettings) {
      setLocalTimerSettings({
        ...localTimerSettings,
        enabled,
      })
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {valves.map((valve) => (
        <Card key={valve.id}>
          <CardHeader>
            <CardTitle>{valve.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="flex flex-col space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Power className="h-5 w-5" />
                    <Label htmlFor={`valve-${valve.id}-switch`}>Valve Power</Label>
                  </div>
                  <Switch
                    id={`valve-${valve.id}-switch`}
                    checked={valve.state}
                    onCheckedChange={(state) => onValveStateChange(valve.id, state)}
                    disabled={valve.timer.enabled}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-5 w-5" />
                    <Label htmlFor={`valve-${valve.id}-timer-switch`}>Timer Control</Label>
                  </div>
                  <Switch
                    id={`valve-${valve.id}-timer-switch`}
                    checked={valve.timer.enabled}
                    onCheckedChange={(enabled) => {
                      onValveTimerChange(valve.id, {
                        ...valve.timer,
                        enabled,
                      })
                    }}
                  />
                </div>
              </div>

              <div className="pt-2 border-t">
                <h3 className="text-sm font-medium mb-2">Status</h3>
                <div className="flex items-center space-x-2">
                  <Badge variant={valve.state ? "default" : "outline"}>
                    <Power className="h-3 w-3 mr-1" />
                    {valve.state ? "Open" : "Closed"}
                  </Badge>

                  {valve.timer.enabled && (
                    <Badge variant="secondary">
                      <Clock className="h-3 w-3 mr-1" />
                      Timer Active
                    </Badge>
                  )}
                </div>
              </div>

              {valve.timer.enabled && valve.timer.schedules.length > 0 && (
                <div className="pt-2 border-t">
                  <h3 className="text-sm font-medium mb-2">Active Schedules</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {valve.timer.schedules.map((schedule) => (
                      <div key={schedule.id} className="text-sm p-2 bg-muted rounded-md">
                        <div className="font-medium">
                          {schedule.startTime} - {schedule.endTime}
                        </div>
                        <div className="text-xs text-muted-foreground">{schedule.days.join(", ")}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-2">
                <Button variant="outline" size="sm" onClick={() => handleOpenTimerSettings(valve)}>
                  <Clock className="h-4 w-4 mr-2" />
                  Timer Settings
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      {showTimerSettings && selectedValve && localTimerSettings && (
        <Dialog open={showTimerSettings} onOpenChange={setShowTimerSettings}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Timer Settings - {selectedValve.name}</DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <div className="flex items-center space-x-2 py-4">
                <Switch id="timer-enabled" checked={localTimerSettings.enabled} onCheckedChange={toggleTimer} />
                <Label htmlFor="timer-enabled">Enable Timer</Label>
              </div>

              <TimerSettingsContent timerSettings={localTimerSettings} setTimerSettings={setLocalTimerSettings} />
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowTimerSettings(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveTimerSettings}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

// Reusing timer settings component logic
function TimerSettingsContent({
  timerSettings,
  setTimerSettings,
}: {
  timerSettings: ValveTimerSettings
  setTimerSettings: (settings: ValveTimerSettings) => void
}) {
  const DAYS_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

  const addSchedule = () => {
    const newSchedule: Schedule = {
      id: Date.now().toString(),
      startTime: "08:00",
      endTime: "17:00",
      days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    }

    setTimerSettings({
      ...timerSettings,
      schedules: [...timerSettings.schedules, newSchedule],
    })
  }

  const removeSchedule = (id: string) => {
    setTimerSettings({
      ...timerSettings,
      schedules: timerSettings.schedules.filter((schedule) => schedule.id !== id),
    })
  }

  const updateSchedule = (id: string, field: keyof Schedule, value: string | string[]) => {
    setTimerSettings({
      ...timerSettings,
      schedules: timerSettings.schedules.map((schedule) => {
        if (schedule.id === id) {
          return {
            ...schedule,
            [field]: value,
          }
        }
        return schedule
      }),
    })
  }

  const toggleDay = (scheduleId: string, day: string) => {
    const schedule = timerSettings.schedules.find((s) => s.id === scheduleId)
    if (!schedule) return

    const days = schedule.days.includes(day) ? schedule.days.filter((d) => d !== day) : [...schedule.days, day]

    updateSchedule(scheduleId, "days", days)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Schedules</h3>
        <Button variant="outline" size="sm" onClick={addSchedule} disabled={!timerSettings.enabled}>
          <Clock className="h-4 w-4 mr-2" />
          Add Schedule
        </Button>
      </div>

      {timerSettings.schedules.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          No schedules added. Click "Add Schedule" to create one.
        </div>
      ) : (
        <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
          {timerSettings.schedules.map((schedule) => (
            <Card key={schedule.id}>
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="grid grid-cols-2 gap-4 flex-1">
                    <div className="space-y-2">
                      <Label htmlFor={`start-time-${schedule.id}`}>Start Time</Label>
                      <input
                        id={`start-time-${schedule.id}`}
                        type="time"
                        value={schedule.startTime}
                        onChange={(e) => updateSchedule(schedule.id, "startTime", e.target.value)}
                        disabled={!timerSettings.enabled}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor={`end-time-${schedule.id}`}>End Time</Label>
                      <input
                        id={`end-time-${schedule.id}`}
                        type="time"
                        value={schedule.endTime}
                        onChange={(e) => updateSchedule(schedule.id, "endTime", e.target.value)}
                        disabled={!timerSettings.enabled}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeSchedule(schedule.id)}
                    disabled={!timerSettings.enabled}
                    className="ml-2"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-4 w-4"
                    >
                      <path d="M3 6h18"></path>
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                    </svg>
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label>Days of Week</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {DAYS_OF_WEEK.map((day) => (
                      <div key={day} className="flex items-center space-x-2">
                        <Checkbox
                          id={`${schedule.id}-${day}`}
                          checked={schedule.days.includes(day)}
                          onCheckedChange={() => toggleDay(schedule.id, day)}
                          disabled={!timerSettings.enabled}
                        />
                        <Label htmlFor={`${schedule.id}-${day}`} className="text-sm">
                          {day}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
