"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { Plus, Trash2 } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type Schedule = {
  id: string
  startTime: string
  endTime: string
  days: string[]
}

type DeviceTimerSettings = {
  enabled: boolean
  schedules: Schedule[]
}

export type TimerSettings = {
  pump: DeviceTimerSettings
  heatPump: DeviceTimerSettings
}

interface TimerSettingsProps {
  timerSettings: TimerSettings
  setTimerSettings: (settings: TimerSettings) => void
  onClose: () => void
}

const DAYS_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

export function TimerSettings({ timerSettings, setTimerSettings, onClose }: TimerSettingsProps) {
  const [localSettings, setLocalSettings] = useState<TimerSettings>({
    pump: {
      ...timerSettings.pump,
      schedules: [...timerSettings.pump.schedules],
    },
    heatPump: {
      ...timerSettings.heatPump,
      schedules: [...timerSettings.heatPump.schedules],
    },
  })

  const handleSave = () => {
    setTimerSettings(localSettings)
    onClose()
  }

  const toggleEnabled = (device: "pump" | "heatPump") => {
    setLocalSettings((prev) => ({
      ...prev,
      [device]: {
        ...prev[device],
        enabled: !prev[device].enabled,
      },
    }))
  }

  const addSchedule = (device: "pump" | "heatPump") => {
    const newSchedule: Schedule = {
      id: Date.now().toString(),
      startTime: "08:00",
      endTime: "17:00",
      days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    }

    setLocalSettings((prev) => ({
      ...prev,
      [device]: {
        ...prev[device],
        schedules: [...prev[device].schedules, newSchedule],
      },
    }))
  }

  const removeSchedule = (device: "pump" | "heatPump", id: string) => {
    setLocalSettings((prev) => ({
      ...prev,
      [device]: {
        ...prev[device],
        schedules: prev[device].schedules.filter((schedule) => schedule.id !== id),
      },
    }))
  }

  const updateSchedule = (device: "pump" | "heatPump", id: string, field: keyof Schedule, value: string | string[]) => {
    setLocalSettings((prev) => ({
      ...prev,
      [device]: {
        ...prev[device],
        schedules: prev[device].schedules.map((schedule) => {
          if (schedule.id === id) {
            return {
              ...schedule,
              [field]: value,
            }
          }
          return schedule
        }),
      },
    }))
  }

  const toggleDay = (device: "pump" | "heatPump", scheduleId: string, day: string) => {
    const schedule = localSettings[device].schedules.find((s) => s.id === scheduleId)
    if (!schedule) return

    const days = schedule.days.includes(day) ? schedule.days.filter((d) => d !== day) : [...schedule.days, day]

    updateSchedule(device, scheduleId, "days", days)
  }

  const renderDeviceTimerSettings = (device: "pump" | "heatPump", title: string) => (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 py-4">
        <Switch
          id={`${device}-timer-enabled`}
          checked={localSettings[device].enabled}
          onCheckedChange={() => toggleEnabled(device)}
        />
        <Label htmlFor={`${device}-timer-enabled`}>Enable Timer</Label>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Schedules</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={() => addSchedule(device)}
            disabled={!localSettings[device].enabled}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Schedule
          </Button>
        </div>

        <ScrollArea className="h-[300px] pr-4">
          {localSettings[device].schedules.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No schedules added. Click "Add Schedule" to create one.
            </div>
          ) : (
            <div className="space-y-4">
              {localSettings[device].schedules.map((schedule) => (
                <Card key={schedule.id}>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start mb-4">
                      <div className="grid grid-cols-2 gap-4 flex-1">
                        <div className="space-y-2">
                          <Label htmlFor={`${device}-start-time-${schedule.id}`}>Start Time</Label>
                          <Input
                            id={`${device}-start-time-${schedule.id}`}
                            type="time"
                            value={schedule.startTime}
                            onChange={(e) => updateSchedule(device, schedule.id, "startTime", e.target.value)}
                            disabled={!localSettings[device].enabled}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`${device}-end-time-${schedule.id}`}>End Time</Label>
                          <Input
                            id={`${device}-end-time-${schedule.id}`}
                            type="time"
                            value={schedule.endTime}
                            onChange={(e) => updateSchedule(device, schedule.id, "endTime", e.target.value)}
                            disabled={!localSettings[device].enabled}
                          />
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSchedule(device, schedule.id)}
                        disabled={!localSettings[device].enabled}
                        className="ml-2"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <Label>Days of Week</Label>
                      <div className="grid grid-cols-4 gap-2">
                        {DAYS_OF_WEEK.map((day) => (
                          <div key={day} className="flex items-center space-x-2">
                            <Checkbox
                              id={`${device}-${schedule.id}-${day}`}
                              checked={schedule.days.includes(day)}
                              onCheckedChange={() => toggleDay(device, schedule.id, day)}
                              disabled={!localSettings[device].enabled}
                            />
                            <Label htmlFor={`${device}-${schedule.id}-${day}`} className="text-sm">
                              {day}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </ScrollArea>
      </div>
    </div>
  )

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Timer Settings</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="pump">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="pump">Pump Timer</TabsTrigger>
            <TabsTrigger value="heatPump">Heat Pump Timer</TabsTrigger>
          </TabsList>

          <TabsContent value="pump">{renderDeviceTimerSettings("pump", "Pump Timer Settings")}</TabsContent>

          <TabsContent value="heatPump">
            {renderDeviceTimerSettings("heatPump", "Heat Pump Timer Settings")}
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
