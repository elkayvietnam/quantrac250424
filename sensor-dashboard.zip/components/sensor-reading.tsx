import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowDown, ArrowUp, Minus, Bell } from "lucide-react"
import { Progress } from "@/components/ui/progress"

interface SensorReadingProps {
  title: string
  value: number
  unit: string
  trend: "rising" | "falling" | "stable"
  alarm: boolean
  min: number
  max: number
}

export function SensorReading({ title, value, unit, trend, alarm, min, max }: SensorReadingProps) {
  const getTrendIcon = () => {
    switch (trend) {
      case "rising":
        return <ArrowUp className="h-4 w-4 text-green-500" />
      case "falling":
        return <ArrowDown className="h-4 w-4 text-red-500" />
      case "stable":
        return <Minus className="h-4 w-4 text-gray-500" />
    }
  }

  const getProgressValue = () => {
    // Calculate percentage within the range
    const range = max - min
    const position = value - min
    return Math.max(0, Math.min(100, (position / range) * 100))
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex justify-between items-center">
          {title}
          {alarm && (
            <Badge variant="destructive">
              <Bell className="h-3 w-3 mr-1" />
              Alarm
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-2">
          <div className="text-3xl font-bold">
            {value} {unit && <span className="text-sm font-normal">{unit}</span>}
          </div>
          <div className="flex items-center">
            {getTrendIcon()}
            <span className="ml-1 text-sm">{trend}</span>
          </div>
        </div>
        <div className="space-y-1">
          <Progress value={getProgressValue()} />
          <div className="flex justify-between text-xs">
            <span>{min}</span>
            <span>{max}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
