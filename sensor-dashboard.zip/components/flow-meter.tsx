"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowDown, ArrowUp, Minus, Droplet, RotateCw } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export type FlowMeterData = {
  id: string
  name: string
  currentFlow: number // in m³/h
  totalFlow: number // in m³
  maxFlow: number // in m³/h
  trend: "rising" | "falling" | "stable"
  history: Array<{ time: string; value: number }>
}

interface FlowMeterProps {
  flowMeter: FlowMeterData
  onResetTotalFlow: (id: string) => void
}

export function FlowMeter({ flowMeter, onResetTotalFlow }: FlowMeterProps) {
  const getTrendIcon = (trend: "rising" | "falling" | "stable") => {
    switch (trend) {
      case "rising":
        return <ArrowUp className="h-4 w-4 text-green-500" />
      case "falling":
        return <ArrowDown className="h-4 w-4 text-red-500" />
      case "stable":
        return <Minus className="h-4 w-4 text-gray-500" />
    }
  }

  const getProgressValue = (current: number, max: number) => {
    return Math.min(100, Math.round((current / max) * 100))
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex justify-between items-center">
          {flowMeter.name}
          <Badge variant="outline" className="ml-2">
            <Droplet className="h-3 w-3 mr-1" />
            Flow Meter
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="text-3xl font-bold">
            {flowMeter.currentFlow.toFixed(2)} <span className="text-sm">m³/h</span>
          </div>
          <div className="flex items-center">
            {getTrendIcon(flowMeter.trend)}
            <span className="ml-1 text-sm">{flowMeter.trend}</span>
          </div>
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-xs">
            <span>0 m³/h</span>
            <span>{flowMeter.maxFlow} m³/h</span>
          </div>
          <Progress value={getProgressValue(flowMeter.currentFlow, flowMeter.maxFlow)} />
        </div>

        <div className="pt-4 border-t">
          <div className="flex justify-between items-center mb-2">
            <div className="text-sm font-medium">Total Flow</div>
            <Button variant="outline" size="sm" onClick={() => onResetTotalFlow(flowMeter.id)}>
              <RotateCw className="h-3 w-3 mr-1" />
              Reset
            </Button>
          </div>
          <div className="text-2xl font-bold">
            {flowMeter.totalFlow.toFixed(2)} <span className="text-sm">m³</span>
          </div>
        </div>

        <div className="pt-4 border-t">
          <div className="text-sm font-medium mb-2">Flow History</div>
          <div className="h-[150px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={flowMeter.history} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                <YAxis domain={[0, flowMeter.maxFlow]} tick={{ fontSize: 10 }} />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={{ r: 2 }}
                  activeDot={{ r: 4 }}
                  name="Flow Rate (m³/h)"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
