"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Bell, Clock, Settings, LogOut } from "lucide-react"
import { AlarmSettings } from "@/components/alarm-settings"
import { TimerSettings } from "@/components/timer-settings"
import { ApiConfiguration, type TuyaConfig } from "@/components/api-configuration"

interface AdminSettingsProps {
  alarmThresholds: any
  setAlarmThresholds: (thresholds: any) => void
  timerSettings: any
  setTimerSettings: (settings: any) => void
  tuyaConfig: TuyaConfig
  onSaveTuyaConfig: (config: TuyaConfig) => void
  onLogout: () => void
}

export function AdminSettings({
  alarmThresholds,
  setAlarmThresholds,
  timerSettings,
  setTimerSettings,
  tuyaConfig,
  onSaveTuyaConfig,
  onLogout,
}: AdminSettingsProps) {
  const [showAlarmSettings, setShowAlarmSettings] = useState(false)
  const [showTimerSettings, setShowTimerSettings] = useState(false)
  const [showApiConfig, setShowApiConfig] = useState(false)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Admin Settings</h2>
        <Button variant="outline" size="sm" onClick={onLogout}>
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>System Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button onClick={() => setShowAlarmSettings(true)} className="w-full">
              <Bell className="h-4 w-4 mr-2" />
              Alarm Settings
            </Button>
            <Button onClick={() => setShowTimerSettings(true)} className="w-full">
              <Clock className="h-4 w-4 mr-2" />
              Timer Settings
            </Button>
            <Button onClick={() => setShowApiConfig(true)} className="w-full">
              <Settings className="h-4 w-4 mr-2" />
              API Settings
            </Button>
          </div>
        </CardContent>
      </Card>

      {showAlarmSettings && (
        <AlarmSettings
          alarmThresholds={alarmThresholds}
          setAlarmThresholds={setAlarmThresholds}
          onClose={() => setShowAlarmSettings(false)}
        />
      )}

      {showTimerSettings && (
        <TimerSettings
          timerSettings={timerSettings}
          setTimerSettings={setTimerSettings}
          onClose={() => setShowTimerSettings(false)}
        />
      )}

      {showApiConfig && (
        <ApiConfiguration
          open={showApiConfig}
          onClose={() => setShowApiConfig(false)}
          onSave={onSaveTuyaConfig}
          config={tuyaConfig}
        />
      )}
    </div>
  )
}
