"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { AlertTriangle, RotateCw, Clock } from "lucide-react"

export type FilterStatus = {
  id: string
  name: string
  runtime: number // in hours
  maxRuntime: number // in hours
  lastReplaced: string // ISO date string
}

interface FilterMaintenanceProps {
  filters: FilterStatus[]
  onResetFilter: (id: string) => void
  onUpdateMaxRuntime: (id: string, maxRuntime: number) => void
}

export function FilterMaintenance({ filters, onResetFilter, onUpdateMaxRuntime }: FilterMaintenanceProps) {
  const [showSettings, setShowSettings] = useState(false)
  const [selectedFilter, setSelectedFilter] = useState<FilterStatus | null>(null)
  const [newMaxRuntime, setNewMaxRuntime] = useState(0)

  const handleOpenSettings = (filter: FilterStatus) => {
    setSelectedFilter(filter)
    setNewMaxRuntime(filter.maxRuntime)
    setShowSettings(true)
  }

  const handleSaveSettings = () => {
    if (selectedFilter && newMaxRuntime > 0) {
      onUpdateMaxRuntime(selectedFilter.id, newMaxRuntime)
    }
    setShowSettings(false)
  }

  const getUsagePercentage = (runtime: number, maxRuntime: number) => {
    return Math.min(100, Math.round((runtime / maxRuntime) * 100))
  }

  const getStatusBadge = (runtime: number, maxRuntime: number) => {
    const percentage = (runtime / maxRuntime) * 100

    if (percentage >= 100) {
      return (
        <Badge variant="destructive" className="ml-2">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Replace Now
        </Badge>
      )
    } else if (percentage >= 90) {
      return (
        <Badge variant="warning" className="ml-2 bg-yellow-500">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Replace Soon
        </Badge>
      )
    } else if (percentage >= 75) {
      return (
        <Badge variant="outline" className="ml-2 border-yellow-500 text-yellow-500">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Maintenance Due
        </Badge>
      )
    }

    return (
      <Badge variant="outline" className="ml-2">
        Good Condition
      </Badge>
    )
  }

  const formatRuntime = (hours: number) => {
    const days = Math.floor(hours / 24)
    const remainingHours = Math.floor(hours % 24)

    if (days > 0) {
      return `${days}d ${remainingHours}h`
    }
    return `${remainingHours}h`
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filters.map((filter) => {
          const usagePercentage = getUsagePercentage(filter.runtime, filter.maxRuntime)

          return (
            <Card key={filter.id} className={usagePercentage >= 100 ? "border-red-500" : ""}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex justify-between items-center">
                  <span>{filter.name}</span>
                  {getStatusBadge(filter.runtime, filter.maxRuntime)}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Runtime:</span>
                    <span className="font-medium">{formatRuntime(filter.runtime)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Max Runtime:</span>
                    <span className="font-medium">{formatRuntime(filter.maxRuntime)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Last Replaced:</span>
                    <span className="font-medium">{new Date(filter.lastReplaced).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>0%</span>
                    <span>{usagePercentage}%</span>
                    <span>100%</span>
                  </div>
                  <Progress
                    value={usagePercentage}
                    className={usagePercentage >= 90 ? "bg-red-100" : usagePercentage >= 75 ? "bg-yellow-100" : ""}
                  />
                </div>

                <div className="flex justify-between pt-2">
                  <Button variant="outline" size="sm" onClick={() => handleOpenSettings(filter)}>
                    <Clock className="h-4 w-4 mr-2" />
                    Settings
                  </Button>
                  <Button
                    variant={usagePercentage >= 75 ? "default" : "outline"}
                    size="sm"
                    onClick={() => onResetFilter(filter.id)}
                  >
                    <RotateCw className="h-4 w-4 mr-2" />
                    Reset
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {showSettings && selectedFilter && (
        <Dialog open={showSettings} onOpenChange={setShowSettings}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Filter Settings - {selectedFilter.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="max-runtime">Maximum Runtime (hours)</Label>
                <Input
                  id="max-runtime"
                  type="number"
                  value={newMaxRuntime}
                  onChange={(e) => setNewMaxRuntime(Number(e.target.value))}
                  min={1}
                />
              </div>
              <div className="text-sm text-muted-foreground">
                Set the maximum runtime before filter replacement is required.
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowSettings(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveSettings}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
