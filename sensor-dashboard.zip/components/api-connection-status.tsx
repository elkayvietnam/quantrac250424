"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Wifi, WifiOff, RefreshCw } from "lucide-react"
import type { ConnectionStatus } from "@/lib/tuya-api"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface ApiConnectionStatusProps {
  status: ConnectionStatus
  onRefresh: () => void
  lastUpdated: Date | null
}

export function ApiConnectionStatus({ status, onRefresh, lastUpdated }: ApiConnectionStatusProps) {
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = async () => {
    setIsRefreshing(true)
    await onRefresh()
    setIsRefreshing(false)
  }

  const getStatusDetails = () => {
    switch (status) {
      case "connected":
        return {
          icon: <Wifi className="h-4 w-4" />,
          label: "Connected",
          variant: "success" as const,
          color: "text-green-500",
        }
      case "disconnected":
        return {
          icon: <WifiOff className="h-4 w-4" />,
          label: "Disconnected",
          variant: "outline" as const,
          color: "text-gray-500",
        }
      case "error":
        return {
          icon: <WifiOff className="h-4 w-4" />,
          label: "Connection Error",
          variant: "destructive" as const,
          color: "text-red-500",
        }
      case "initializing":
        return {
          icon: <RefreshCw className="h-4 w-4 animate-spin" />,
          label: "Connecting...",
          variant: "outline" as const,
          color: "text-yellow-500",
        }
    }
  }

  const statusDetails = getStatusDetails()
  const lastUpdatedText = lastUpdated ? `Last updated: ${lastUpdated.toLocaleTimeString()}` : "Not yet updated"

  return (
    <div className="flex items-center gap-2">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge variant={statusDetails.variant} className="flex items-center gap-1">
              {statusDetails.icon}
              <span>{statusDetails.label}</span>
            </Badge>
          </TooltipTrigger>
          <TooltipContent>
            <p>{lastUpdatedText}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <Button variant="ghost" size="icon" onClick={handleRefresh} disabled={isRefreshing} className="h-8 w-8">
        <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
        <span className="sr-only">Refresh connection</span>
      </Button>
    </div>
  )
}
