"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type FlowData = {
  flow1: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
  flow2: { value: number; trend: "rising" | "falling" | "stable"; alarm: boolean }
}

type FlowThresholds = {
  flow1: { min: number; max: number }
  flow2: { min: number; max: number }
}

interface FlowChartProps {
  flowData: FlowData
  flowThresholds: FlowThresholds
}

// Generate mock historical data
const generateHistoricalData = (currentValue: number, min: number, max: number, dataPoints = 24) => {
  const data = []
  let value = currentValue

  const now = new Date()

  for (let i = dataPoints - 1; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 3600000) // hourly data
    const timeStr = time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })

    // Random walk with boundaries
    const change = (Math.random() - 0.5) * (max - min) * 0.05
    value = Math.max(min * 0.9, Math.min(max * 1.1, value + change))

    data.push({
      time: timeStr,
      value: Number.parseFloat(value.toFixed(2)),
    })
  }

  return data
}

export function FlowChart({ flowData, flowThresholds }: FlowChartProps) {
  // Generate historical data for each flow meter
  const [flow1Data] = useState(
    generateHistoricalData(flowData.flow1.value, flowThresholds.flow1.min, flowThresholds.flow1.max),
  )

  const [flow2Data] = useState(
    generateHistoricalData(flowData.flow2.value, flowThresholds.flow2.min, flowThresholds.flow2.max),
  )

  return (
    <div className="space-y-6">
      <Tabs defaultValue="flow1">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="flow1">Main Flow Meter</TabsTrigger>
          <TabsTrigger value="flow2">Hot Water Flow Meter</TabsTrigger>
        </TabsList>

        <TabsContent value="flow1">
          <Card>
            <CardHeader>
              <CardTitle>Main Flow Meter History (m³/h)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={flow1Data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis
                      domain={[
                        Math.min(flowThresholds.flow1.min * 0.9, Math.min(...flow1Data.map((d) => d.value))),
                        Math.max(flowThresholds.flow1.max * 1.1, Math.max(...flow1Data.map((d) => d.value))),
                      ]}
                    />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine y={flowThresholds.flow1.min} stroke="red" strokeDasharray="3 3" />
                    <ReferenceLine y={flowThresholds.flow1.max} stroke="red" strokeDasharray="3 3" />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#3b82f6"
                      activeDot={{ r: 8 }}
                      name="Flow Rate (m³/h)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flow2">
          <Card>
            <CardHeader>
              <CardTitle>Hot Water Flow Meter History (m³/h)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={flow2Data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis
                      domain={[
                        Math.min(flowThresholds.flow2.min * 0.9, Math.min(...flow2Data.map((d) => d.value))),
                        Math.max(flowThresholds.flow2.max * 1.1, Math.max(...flow2Data.map((d) => d.value))),
                      ]}
                    />
                    <Tooltip />
                    <Legend />
                    <ReferenceLine y={flowThresholds.flow2.min} stroke="red" strokeDasharray="3 3" />
                    <ReferenceLine y={flowThresholds.flow2.max} stroke="red" strokeDasharray="3 3" />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#ef4444"
                      activeDot={{ r: 8 }}
                      name="Flow Rate (m³/h)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
