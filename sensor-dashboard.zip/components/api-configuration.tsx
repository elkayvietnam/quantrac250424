"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { testConnection } from "@/lib/tuya-api"
import { Badge } from "@/components/ui/badge"
import { Wifi, WifiOff, RefreshCw } from "lucide-react"

interface ApiConfigurationProps {
  open: boolean
  onClose: () => void
  onSave: (config: TuyaConfig) => void
  config: TuyaConfig
}

export type TuyaConfig = {
  apiEndpoint: string
  accessId: string
  accessSecret: string
  devices: {
    ph: string
    conductivity: string
    temperature: string
    pressure: string
    salinity1: string
    salinity2: string
    pump: string
    heatPump: string
  }
}

export function ApiConfiguration({ open, onClose, onSave, config }: ApiConfigurationProps) {
  const [localConfig, setLocalConfig] = useState<TuyaConfig>({ ...config })
  const [testStatus, setTestStatus] = useState<"idle" | "testing" | "success" | "error">("idle")
  const [testMessage, setTestMessage] = useState("")

  const handleSave = () => {
    onSave(localConfig)
    onClose()
  }

  const handleChange = (section: "api" | "devices", field: string, value: string) => {
    if (section === "api") {
      setLocalConfig((prev) => ({
        ...prev,
        [field]: value,
      }))
    } else {
      setLocalConfig((prev) => ({
        ...prev,
        devices: {
          ...prev.devices,
          [field]: value,
        },
      }))
    }
  }

  const handleTestConnection = async () => {
    setTestStatus("testing")
    try {
      // In a real implementation, we would use the local config for testing
      // For demonstration, we're using the testConnection function directly
      const result = await testConnection()

      if (result.status === "connected") {
        setTestStatus("success")
      } else {
        setTestStatus("error")
      }
      setTestMessage(result.message)
    } catch (error) {
      setTestStatus("error")
      setTestMessage(error instanceof Error ? error.message : "Unknown error")
    }
  }

  const getTestStatusBadge = () => {
    switch (testStatus) {
      case "idle":
        return null
      case "testing":
        return (
          <Badge variant="outline" className="ml-2">
            <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
            Testing...
          </Badge>
        )
      case "success":
        return (
          <Badge variant="success" className="ml-2">
            <Wifi className="h-3 w-3 mr-1" />
            Connected
          </Badge>
        )
      case "error":
        return (
          <Badge variant="destructive" className="ml-2">
            <WifiOff className="h-3 w-3 mr-1" />
            Connection Failed
          </Badge>
        )
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Tuya API Configuration</DialogTitle>
          {!config.accessId && !config.accessSecret && (
            <p className="text-sm text-muted-foreground mt-2">
              Configure your Tuya API credentials to connect to your sensors and devices. You can get these credentials
              from the Tuya IoT Platform.
            </p>
          )}
        </DialogHeader>

        <Tabs defaultValue="api">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="api">API Settings</TabsTrigger>
            <TabsTrigger value="devices">Device IDs</TabsTrigger>
          </TabsList>

          <TabsContent value="api" className="space-y-4 pt-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="api-endpoint">API Endpoint</Label>
                <Input
                  id="api-endpoint"
                  value={localConfig.apiEndpoint}
                  onChange={(e) => handleChange("api", "apiEndpoint", e.target.value)}
                  placeholder="https://openapi.tuyacn.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="access-id">Access ID</Label>
                <Input
                  id="access-id"
                  value={localConfig.accessId}
                  onChange={(e) => handleChange("api", "accessId", e.target.value)}
                  placeholder="Your Tuya Access ID"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="access-secret">Access Secret</Label>
                <Input
                  id="access-secret"
                  type="password"
                  value={localConfig.accessSecret}
                  onChange={(e) => handleChange("api", "accessSecret", e.target.value)}
                  placeholder="Your Tuya Access Secret"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <div>
                  {getTestStatusBadge()}
                  {testStatus === "error" && <p className="text-xs text-red-500 mt-1">{testMessage}</p>}
                </div>
                <Button onClick={handleTestConnection} disabled={testStatus === "testing"}>
                  Test Connection
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="devices" className="space-y-4 pt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ph-device">pH Sensor Device ID</Label>
                <Input
                  id="ph-device"
                  value={localConfig.devices.ph}
                  onChange={(e) => handleChange("devices", "ph", e.target.value)}
                  placeholder="Device ID for pH sensor"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="conductivity-device">Conductivity Sensor Device ID</Label>
                <Input
                  id="conductivity-device"
                  value={localConfig.devices.conductivity}
                  onChange={(e) => handleChange("devices", "conductivity", e.target.value)}
                  placeholder="Device ID for conductivity sensor"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="temperature-device">Temperature Sensor Device ID</Label>
                <Input
                  id="temperature-device"
                  value={localConfig.devices.temperature}
                  onChange={(e) => handleChange("devices", "temperature", e.target.value)}
                  placeholder="Device ID for temperature sensor"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pressure-device">Pressure Sensor Device ID</Label>
                <Input
                  id="pressure-device"
                  value={localConfig.devices.pressure}
                  onChange={(e) => handleChange("devices", "pressure", e.target.value)}
                  placeholder="Device ID for pressure sensor"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="salinity1-device">Salinity 1 Sensor Device ID</Label>
                <Input
                  id="salinity1-device"
                  value={localConfig.devices.salinity1}
                  onChange={(e) => handleChange("devices", "salinity1", e.target.value)}
                  placeholder="Device ID for salinity 1 sensor"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="salinity2-device">Salinity 2 Sensor Device ID</Label>
                <Input
                  id="salinity2-device"
                  value={localConfig.devices.salinity2}
                  onChange={(e) => handleChange("devices", "salinity2", e.target.value)}
                  placeholder="Device ID for salinity 2 sensor"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pump-device">Pump Device ID</Label>
                <Input
                  id="pump-device"
                  value={localConfig.devices.pump}
                  onChange={(e) => handleChange("devices", "pump", e.target.value)}
                  placeholder="Device ID for pump"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="heat-pump-device">Heat Pump Device ID</Label>
                <Input
                  id="heat-pump-device"
                  value={localConfig.devices.heatPump}
                  onChange={(e) => handleChange("devices", "heatPump", e.target.value)}
                  placeholder="Device ID for heat pump"
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Configuration</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
