"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type AlarmThresholds = {
  ph: { min: number; max: number }
  conductivity: { min: number; max: number }
  temperature: { min: number; max: number }
  pressure: { min: number; max: number }
  salinity1: { min: number; max: number }
  salinity2: { min: number; max: number }
}

interface AlarmSettingsProps {
  alarmThresholds: AlarmThresholds
  setAlarmThresholds: (thresholds: AlarmThresholds) => void
  onClose: () => void
}

export function AlarmSettings({ alarmThresholds, setAlarmThresholds, onClose }: AlarmSettingsProps) {
  const [localThresholds, setLocalThresholds] = useState<AlarmThresholds>({ ...alarmThresholds })

  const handleSave = () => {
    setAlarmThresholds(localThresholds)
    onClose()
  }

  const handleChange = (sensor: keyof AlarmThresholds, type: "min" | "max", value: string) => {
    const numValue = Number.parseFloat(value)
    if (!isNaN(numValue)) {
      setLocalThresholds((prev) => ({
        ...prev,
        [sensor]: {
          ...prev[sensor],
          [type]: numValue,
        },
      }))
    }
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Alarm Settings</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="ph">
          <TabsList className="grid grid-cols-3 md:grid-cols-6">
            <TabsTrigger value="ph">pH</TabsTrigger>
            <TabsTrigger value="conductivity">Conductivity</TabsTrigger>
            <TabsTrigger value="temperature">Temperature</TabsTrigger>
            <TabsTrigger value="pressure">Pressure</TabsTrigger>
            <TabsTrigger value="salinity1">Salinity 1</TabsTrigger>
            <TabsTrigger value="salinity2">Salinity 2</TabsTrigger>
          </TabsList>

          <TabsContent value="ph" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ph-min">Minimum Threshold</Label>
                <Input
                  id="ph-min"
                  type="number"
                  step="0.1"
                  value={localThresholds.ph.min}
                  onChange={(e) => handleChange("ph", "min", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ph-max">Maximum Threshold</Label>
                <Input
                  id="ph-max"
                  type="number"
                  step="0.1"
                  value={localThresholds.ph.max}
                  onChange={(e) => handleChange("ph", "max", e.target.value)}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="conductivity" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="conductivity-min">Minimum Threshold (μS/cm)</Label>
                <Input
                  id="conductivity-min"
                  type="number"
                  value={localThresholds.conductivity.min}
                  onChange={(e) => handleChange("conductivity", "min", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="conductivity-max">Maximum Threshold (μS/cm)</Label>
                <Input
                  id="conductivity-max"
                  type="number"
                  value={localThresholds.conductivity.max}
                  onChange={(e) => handleChange("conductivity", "max", e.target.value)}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="temperature" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="temperature-min">Minimum Threshold (°C)</Label>
                <Input
                  id="temperature-min"
                  type="number"
                  step="0.1"
                  value={localThresholds.temperature.min}
                  onChange={(e) => handleChange("temperature", "min", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="temperature-max">Maximum Threshold (°C)</Label>
                <Input
                  id="temperature-max"
                  type="number"
                  step="0.1"
                  value={localThresholds.temperature.max}
                  onChange={(e) => handleChange("temperature", "max", e.target.value)}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="pressure" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pressure-min">Minimum Threshold (bar)</Label>
                <Input
                  id="pressure-min"
                  type="number"
                  step="0.01"
                  value={localThresholds.pressure.min}
                  onChange={(e) => handleChange("pressure", "min", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pressure-max">Maximum Threshold (bar)</Label>
                <Input
                  id="pressure-max"
                  type="number"
                  step="0.01"
                  value={localThresholds.pressure.max}
                  onChange={(e) => handleChange("pressure", "max", e.target.value)}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="salinity1" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="salinity1-min">Minimum Threshold (ppt)</Label>
                <Input
                  id="salinity1-min"
                  type="number"
                  step="0.1"
                  value={localThresholds.salinity1.min}
                  onChange={(e) => handleChange("salinity1", "min", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="salinity1-max">Maximum Threshold (ppt)</Label>
                <Input
                  id="salinity1-max"
                  type="number"
                  step="0.1"
                  value={localThresholds.salinity1.max}
                  onChange={(e) => handleChange("salinity1", "max", e.target.value)}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="salinity2" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="salinity2-min">Minimum Threshold (ppt)</Label>
                <Input
                  id="salinity2-min"
                  type="number"
                  step="0.1"
                  value={localThresholds.salinity2.min}
                  onChange={(e) => handleChange("salinity2", "min", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="salinity2-max">Maximum Threshold (ppt)</Label>
                <Input
                  id="salinity2-max"
                  type="number"
                  step="0.1"
                  value={localThresholds.salinity2.max}
                  onChange={(e) => handleChange("salinity2", "max", e.target.value)}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
