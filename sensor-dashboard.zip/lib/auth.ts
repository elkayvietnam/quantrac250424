// Simple client-side authentication service

// Hardcoded credentials as requested
const ADMIN_USERNAME = "swatec"
const ADMIN_PASSWORD = "14531454"

// Session storage key
const AUTH_KEY = "sensor_dashboard_auth"

// Check if user is authenticated
export function isAuthenticated(): boolean {
  if (typeof window === "undefined") return false

  const authData = sessionStorage.getItem(AUTH_KEY)
  if (!authData) return false

  try {
    const { expiry } = JSON.parse(authData)
    return new Date().getTime() < expiry
  } catch (error) {
    return false
  }
}

// Login function
export function login(username: string, password: string): boolean {
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    // Set session with 2 hour expiry
    const expiry = new Date().getTime() + 2 * 60 * 60 * 1000
    sessionStorage.setItem(AUTH_KEY, JSON.stringify({ expiry }))
    return true
  }
  return false
}

// Logout function
export function logout(): void {
  sessionStorage.removeItem(AUTH_KEY)
}
