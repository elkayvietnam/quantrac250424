# SWATEC Sensor Monitoring Dashboard

Ứng dụng giám sát cảm biến và điều khiển thiết bị cho SWATEC.

## Tính năng

- Giám sát cảm biến pH, độ dẫn điện, nhiệt độ, áp suất, độ mặn và lưu lượng nước
- Điều khiển bơm và bơm nhiệt
- Điều khiển van động cơ
- Theo dõi bảo trì bộ lọc
- Biểu đồ dữ liệu thời gian thực
- Tích hợp API Tuya để kết nối với thiết bị thực

## Cài đặt

1. Clone repository:
\`\`\`bash
git clone https://github.com/your-username/swatec-dashboard.git
cd swatec-dashboard
\`\`\`

2. Cài đặt dependencies:
\`\`\`bash
npm install
\`\`\`

3. Tạo file `.env.local` từ file `.env.local.example` và cập nhật thông tin API Tuya:
\`\`\`bash
cp .env.local.example .env.local
\`\`\`

4. Chạy ứng dụng ở môi trường phát triển:
\`\`\`bash
npm run dev
\`\`\`

## Triển khai lên Hosting

### Triển khai lên Vercel

1. Đăng nhập vào [Vercel](https://vercel.com)
2. Tạo dự án mới và liên kết với repository GitHub
3. Cấu hình các biến môi trường trong phần "Environment Variables"
4. Nhấn "Deploy"

### Triển khai lên Hosting khác

1. Build ứng dụng:
\`\`\`bash
npm run build
\`\`\`

2. Triển khai thư mục `.next` lên hosting của bạn
3. Đảm bảo cấu hình các biến môi trường cần thiết

## Thông tin đăng nhập Admin

- Username: swatec
- Password: 14531454

## Hỗ trợ

Nếu bạn gặp vấn đề, vui lòng liên hệ với đội ngũ hỗ trợ kỹ thuật.
